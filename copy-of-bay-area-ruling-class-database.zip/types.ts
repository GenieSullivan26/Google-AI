

// Fix: Add and export SortKey and SortOrder types for sorting functionality.
export type SortKey = 'wealthInBillions' | 'age' | 'person';
export type SortOrder = 'asc' | 'desc';

export interface Billionaire {
  id: number;
  person: string;
  imageUrl: string;
  wealthInBillions: number;
  companyAffiliations: string;
  industry: string;
  gender: string;
  racialCategory: string;
  age: number | null;
  sourceOfWealth: string;
  inheritanceScore: number | null;
  philanthropyScore: number | null;
  residence: string;
  citizenship: string;
  maritalStatus: string;
  children: number | null;
  education: string;
  about: string;
  campaignContributionsSource: string;
  numberOfContributions: string;
  totalContributions: number | null;
  contributionsToRepublicans: number | null;
  contributionsToDemocrats: number | null;
  contributionsToPACs: number | null;
  contributionsToSuperPACs: number | null;
  contributionsToPropositions: number | null;
  recipientOfLargestContribution: string;
  largestContributionAmount: number | null;
  federalContributions: number | null;
  stateContributions: number | null;
  localContributions: number | null;
}