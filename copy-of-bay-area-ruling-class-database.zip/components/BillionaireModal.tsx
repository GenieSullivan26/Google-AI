
import React, { useState, useEffect } from 'react';
import { Billionaire } from '../types';
import { CloseIcon } from './icons';

interface BillionaireModalProps {
  billionaire: Billionaire | null;
  onClose: () => void;
}

const DetailItem: React.FC<{ label: string; value: string | number | null | undefined }> = ({ label, value }) => {
  if (value === null || value === undefined || value === 'N/A' || value === '') return null;
  return (
    <div className="py-2 flex justify-between items-start gap-4">
      <p className="text-sm font-medium text-slate-500 whitespace-nowrap">{label}</p>
      <p className="text-sm text-slate-800 text-right">{value}</p>
    </div>
  );
};

const formatCurrency = (value: number | null | undefined) => {
    if (value === null || value === undefined) return 'N/A';
    return `$${value.toLocaleString()}`;
}

const BillionaireModal: React.FC<BillionaireModalProps> = ({ billionaire, onClose }) => {
  const [isClosing, setIsClosing] = useState(false);

  useEffect(() => {
    // Reset closing state if billionaire changes (modal is reopened)
    setIsClosing(false);
  }, [billionaire]);

  if (!billionaire) return null;

  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      onClose();
    }, 300); // Match animation duration
  };
  
  const imageUrl = billionaire.imageUrl && billionaire.imageUrl !== 'N/A'
    ? billionaire.imageUrl
    : `https://picsum.photos/seed/${billionaire.id}/800/600`;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" onClick={handleClose}>
      <div 
        className={`bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto relative ${isClosing ? 'animate-fade-out-down' : 'animate-fade-in-up'}`}
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={handleClose} className="absolute top-3 right-3 text-slate-500 hover:text-slate-800 transition-colors z-10 p-2 rounded-full hover:bg-slate-100">
          <CloseIcon className="w-6 h-6" />
        </button>
        
        <div className="p-6 md:p-8">
            <div className="md:flex md:space-x-8">
                <div className="md:w-1/3 flex-shrink-0">
                    <img src={imageUrl} alt={billionaire.person} className="rounded-lg shadow-lg w-full object-cover aspect-square" />
                    <div className="mt-4 text-center md:text-left">
                        <h2 className="text-3xl font-bold text-slate-900 leading-tight">{billionaire.person}</h2>
                        <p className="text-4xl font-light text-indigo-600 mt-1">${billionaire.wealthInBillions.toFixed(2)}B</p>
                        <p className="text-lg text-slate-600 mt-2">{billionaire.companyAffiliations}</p>
                    </div>
                </div>
                <div className="md:w-2/3 mt-6 md:mt-0 space-y-6">
                    <div>
                      <h3 className="text-xl font-bold text-slate-800 border-b pb-2 mb-3">About</h3>
                      <p className="text-slate-700 whitespace-pre-wrap leading-relaxed text-sm">{billionaire.about}</p>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                            <h4 className="text-md font-bold text-slate-800 mb-1">Personal Details</h4>
                            <DetailItem label="Age" value={billionaire.age} />
                            <DetailItem label="Gender" value={billionaire.gender} />
                            <DetailItem label="Marital Status" value={billionaire.maritalStatus} />
                            <DetailItem label="Children" value={billionaire.children} />
                            <DetailItem label="Residence" value={billionaire.residence} />
                            <DetailItem label="Citizenship" value={billionaire.citizenship} />
                            <DetailItem label="Education" value={billionaire.education} />
                        </div>
                         <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                            <h4 className="text-md font-bold text-slate-800 mb-1">Wealth Profile</h4>
                            <DetailItem label="Source of Wealth" value={billionaire.sourceOfWealth} />
                            <DetailItem label="Industry" value={billionaire.industry} />
                            <DetailItem label="Inheritance Score" value={billionaire.inheritanceScore !== null ? `${billionaire.inheritanceScore}/10` : 'N/A'} />
                            <DetailItem label="Philanthropy Score" value={billionaire.philanthropyScore !== null ? `${billionaire.philanthropyScore}/5` : 'N/A'} />
                        </div>
                    </div>
                    
                    {(billionaire.totalContributions ?? 0) > 0 && (
                        <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                            <h3 className="text-md font-bold text-slate-800 mb-1">Campaign Contributions</h3>
                             <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6">
                                <div>
                                    <DetailItem label="Total Contributions" value={formatCurrency(billionaire.totalContributions)} />
                                    <DetailItem label="To Democrats" value={formatCurrency(billionaire.contributionsToDemocrats)} />
                                    <DetailItem label="To Republicans" value={formatCurrency(billionaire.contributionsToRepublicans)} />
                                    <DetailItem label="To PACs" value={formatCurrency(billionaire.contributionsToPACs)} />
                                    <DetailItem label="To SuperPACs" value={formatCurrency(billionaire.contributionsToSuperPACs)} />
                                </div>
                                <div>
                                    <DetailItem label="# of Contributions" value={billionaire.numberOfContributions} />
                                    <DetailItem label="Largest Recipient" value={billionaire.recipientOfLargestContribution} />
                                    <DetailItem label="Largest Amount" value={formatCurrency(billionaire.largestContributionAmount)} />
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
      </div>
       <style>{`
        @keyframes fade-in-up {
            from { opacity: 0; transform: translateY(20px) scale(0.98); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes fade-out-down {
            from { opacity: 1; transform: translateY(0) scale(1); }
            to { opacity: 0; transform: translateY(20px) scale(0.98); }
        }
        .animate-fade-in-up {
            animation: fade-in-up 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94) forwards;
        }
        .animate-fade-out-down {
            animation: fade-out-down 0.3s cubic-bezier(0.55, 0.085, 0.68, 0.53) forwards;
        }
    `}</style>
    </div>
  );
};

export default BillionaireModal;
