

import React from 'react';
import { Billionaire } from '../types';

interface BillionaireCardProps {
  billionaire: Billionaire;
  onSelect: (billionaire: Billionaire) => void;
}

const BillionaireCard: React.FC<BillionaireCardProps> = ({ billionaire, onSelect }) => {
  const imageUrl = billionaire.imageUrl && billionaire.imageUrl !== 'N/A'
    ? billionaire.imageUrl
    : `https://picsum.photos/seed/${billionaire.id}/400/300`;

  return (
    <div 
      className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer transform hover:-translate-y-1 transition-all duration-300 group"
      onClick={() => onSelect(billionaire)}
    >
      <div className="relative">
        <img className="w-full h-48 object-cover" src={imageUrl} alt={billionaire.person} />
        <div className="absolute inset-0 bg-black bg-opacity-20 group-hover:bg-opacity-10 transition-colors duration-300"></div>
      </div>
      <div className="p-4">
        <h3 className="text-xl font-bold text-slate-800 truncate">{billionaire.person}</h3>
        <p className="text-2xl font-light text-indigo-600">${billionaire.wealthInBillions.toFixed(2)}B</p>
        <p className="text-sm text-slate-500 mt-1 truncate">{billionaire.companyAffiliations}</p>
        <p className="text-xs text-slate-400 mt-2 bg-slate-100 inline-block px-2 py-1 rounded-full">{billionaire.industry}</p>
      </div>
    </div>
  );
};

export default BillionaireCard;