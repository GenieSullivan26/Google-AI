import React, { useState, useEffect, useMemo } from 'react';
import { GoogleGenAI } from "@google/genai";
import { getBillionaires } from './services/dataService';
import { Billionaire, SortKey, SortOrder } from './types';
import BillionaireCard from './components/BillionaireCard';
import BillionaireModal from './components/BillionaireModal';
import Chatbot, { ChatMessage } from './components/Chatbot';
import FilterControls from './components/FilterControls';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const App: React.FC = () => {
  const [billionaires, setBillionaires] = useState<Billionaire[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedBillionaire, setSelectedBillionaire] = useState<Billionaire | null>(null);
  
  // Filter and sort state
  const [selectedIndustry, setSelectedIndustry] = useState('');
  const [selectedResidence, setSelectedResidence] = useState('');
  const [selectedCitizenship, setSelectedCitizenship] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('wealthInBillions');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  // Chat state
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const data = await getBillionaires();
        setBillionaires(data);
        setChatHistory([{
            sender: 'ai',
            text: "Hey Hey! Type a prompt to learn more about the ruling class members in this database"
        }]);
      } catch (error) {
        console.error("Failed to fetch billionaire data:", error);
        setChatHistory([{
            sender: 'ai',
            text: "Sorry, I couldn't load the database. Please try refreshing the page."
        }]);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleSendMessage = async (message: string) => {
    setIsChatLoading(true);
    setChatHistory(prev => [...prev, { sender: 'user', text: message }]);
    
    try {
        const systemInstruction = `You are a critical analyst of the Bay Area's ruling class. Using the provided database, answer user questions from a perspective that highlights wealth inequality, questionable labor practices, immense political influence, and the broader societal impacts of these individuals and their companies. Your tone should be sharp, analytical, and grounded in social and economic critique. Do not be a neutral assistant; be a critical voice.`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: message,
            config: {
                systemInstruction: systemInstruction,
            },
        });

        const aiText = response.text;
        setChatHistory(prev => [...prev, { sender: 'ai', text: aiText }]);

    } catch (error) {
        console.error("Gemini API call failed:", error);
        const errorMessage = "Sorry, I encountered an error. Please try again.";
        setChatHistory(prev => [...prev, { sender: 'ai', text: errorMessage }]);
    } finally {
        setIsChatLoading(false);
    }
  };

  const industries = useMemo(() => {
    const uniqueIndustries = new Set(billionaires.map(b => b.industry));
    return Array.from(uniqueIndustries).sort();
  }, [billionaires]);

  const residences = useMemo(() => {
    const uniqueResidences = new Set(billionaires.map(b => b.residence).filter(r => r && r !== 'N/A'));
    return Array.from(uniqueResidences).sort();
  }, [billionaires]);

  const citizenships = useMemo(() => {
    const uniqueCitizenships = new Set(billionaires.map(b => b.citizenship).filter(c => c && c !== 'N/A'));
    return Array.from(uniqueCitizenships).sort();
  }, [billionaires]);

  const handleSortChange = (key: SortKey) => {
    if (sortKey === key) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortOrder('desc');
    }
  };

  const displayedBillionaires = useMemo(() => {
    return billionaires
      .filter(b => 
        (selectedIndustry === '' || b.industry === selectedIndustry) &&
        (selectedResidence === '' || b.residence === selectedResidence) &&
        (selectedCitizenship === '' || b.citizenship === selectedCitizenship)
      )
      .sort((a, b) => {
        const aVal = a[sortKey];
        const bVal = b[sortKey];
        
        if (aVal === null) return 1;
        if (bVal === null) return -1;

        if (typeof aVal === 'string' && typeof bVal === 'string') {
          return sortOrder === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
        }
        if (typeof aVal === 'number' && typeof bVal === 'number') {
          return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
        }
        return 0;
      });
  }, [billionaires, selectedIndustry, selectedResidence, selectedCitizenship, sortKey, sortOrder]);


  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800">
      <header className="py-6 px-4 text-center bg-white shadow-sm">
        <h1 className="text-4xl font-bold text-slate-900 tracking-tight">Bay Area Ruling Class</h1>
        <p className="mt-2 text-lg text-slate-600">Explore the Exploiters of Silicon Valley</p>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <Chatbot 
            messages={chatHistory}
            onSendMessage={handleSendMessage}
            isLoading={isChatLoading}
        />

        <FilterControls 
          industries={industries}
          selectedIndustry={selectedIndustry}
          onIndustryChange={setSelectedIndustry}
          residences={residences}
          selectedResidence={selectedResidence}
          onResidenceChange={setSelectedResidence}
          citizenships={citizenships}
          selectedCitizenship={selectedCitizenship}
          onCitizenshipChange={setSelectedCitizenship}
          sortKey={sortKey}
          sortOrder={sortOrder}
          onSortChange={handleSortChange}
          totalResults={displayedBillionaires.length}
        />
        
        {loading ? (
          <div className="text-center py-20 text-slate-500">Loading database...</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 pt-8 pb-12">
            {displayedBillionaires.map(b => (
              <BillionaireCard key={b.id} billionaire={b} onSelect={setSelectedBillionaire} />
            ))}
          </div>
        )}
      </main>

      <BillionaireModal 
        billionaire={selectedBillionaire}
        onClose={() => setSelectedBillionaire(null)}
      />

       <footer className="text-center py-6 border-t border-slate-200 text-slate-500 text-sm">
          <p>Built with React, Gemini & Tailwind CSS. Data from Forbes & OpenSecrets.</p>
      </footer>
    </div>
  );
};

export default App;